********************
``matplotlib.image``
********************

.. automodule:: matplotlib.image
   :members:
   :undoc-members:
   :show-inheritance:
