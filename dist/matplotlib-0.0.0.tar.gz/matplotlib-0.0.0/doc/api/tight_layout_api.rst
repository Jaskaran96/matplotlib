***************************
``matplotlib.tight_layout``
***************************

.. attention::
    This module is considered internal.

    Its use is deprecated and it will be removed in a future version.

.. automodule:: matplotlib._tight_layout
   :members:
   :undoc-members:
   :show-inheritance:
