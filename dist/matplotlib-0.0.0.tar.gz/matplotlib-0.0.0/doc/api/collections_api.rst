**************************
``matplotlib.collections``
**************************

.. inheritance-diagram:: matplotlib.collections
   :parts: 2
   :private-bases:

.. automodule:: matplotlib.collections
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
