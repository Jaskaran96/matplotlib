:mod:`.backend_tkagg`, :mod:`.backend_tkcairo`
==============================================

.. automodule:: matplotlib.backends.backend_tkagg
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: matplotlib.backends.backend_tkcairo
   :members:
   :undoc-members:
   :show-inheritance:
