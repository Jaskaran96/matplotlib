*********************
``matplotlib.quiver``
*********************

.. currentmodule:: matplotlib.quiver

.. automodule:: matplotlib.quiver
   :no-members:
   :no-inherited-members:

Classes
-------

.. autosummary::
   :toctree: _as_gen/
   :template: autosummary.rst

   Quiver
   QuiverKey
   Barbs
